/* 
 * File:   timer.h
 * Author: 
 *
 * Created on December 30, 2014, 8:07 PM
 */

#ifndef INITTIMER_H
#define	INITTIMER_H

void delayUs(unsigned int delay);

#endif	/* INITTIMER_H */

